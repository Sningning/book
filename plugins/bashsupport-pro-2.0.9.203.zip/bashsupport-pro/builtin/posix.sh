# <html><h2>Setup for interactive mode</h2>
# <p><strong><code>$ENV</code></strong> contains a path to a file, which is executed to setup a shell in interactive mode.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_03">POSIX specification</a></li>
# </ul>
# </html>
declare ENV

# <html><h2>Location of the user&rsquo;s home directory</h2>
# <p><strong><code>$HOME</code></strong> contains the path of the current user&rsquo;s home directory. It&rsquo;s used in tilde expansion.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Variables.html#Bourne-Shell-Variables">Bash manual</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_03">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Output the path to the current user&rsquo;s home directory.</dt>
# <dd>
# <pre><code class="language-bash">echo &quot;$HOME&quot;
# </code></pre>
# </dd>
# <dt>Tilde expansion for the current user</dt>
# <dd>
# <pre><code class="language-bash">echo ~
# </code></pre>
# </dd>
# <dt>Tilde expansion for another user</dt>
# <dd>
# <pre><code class="language-bash">echo ~jane
# </code></pre>
# Output the path to the home directory of user &ldquo;jane&rdquo;. If the user does not exist, then the output depends on your shell&rsquo;s implementation.</dd>
# </dl>
# </html>
declare HOME

# <html><h2>IFS: Characters to separate fields</h2>
# <p>The shell uses each character of the <strong><code>IFS</code></strong> variable as a separator during word splitting.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Variables.html#Bourne-Shell-Variables">IFS in the Bash manual</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05">POSIX specification on field splitting</a></li>
# <li>Advanced Bash–Scripting Guide: <a href="https://tldp.org/LDP/abs/html/internalvariables.html#IFSREF">$IFS</a></li>
# <li>Advanced Bash–Scripting Guide: <a href="https://tldp.org/LDP/abs/html/internalvariables.html#IFSH">$IFS and whitespace</a></li>
# <li>Advanced Bash–Scripting Guide: <a href="https://tldp.org/LDP/abs/html/internalvariables.html#IFSEMPTY">$* and $@ when $IFS is empty</a></li>
# <li>Wikipedia: <a href="https://en.wikipedia.org/wiki/Internal_field_separator">Internal field separator</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>IFS to split a word</dt>
# <dd>
# <pre><code class="language-bash">var1=&quot;a+b+c&quot;
# IFS=+
# echo $var1
# </code></pre>
# </dd>
# </dl>
# </html>
declare IFS

# <html><h2>Language Category Fallback</h2>
# <p><strong><code>$LANG</code></strong> defines the fallback locale category in the absence of the more specific <code>LC_</code> variables, e.g. <code>LC_ALL</code> or <code>LC_TIME</code>.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-LANG">Bash Manual</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_02">POSIX specification</a></li>
# </ul>
# </html>
declare LANG

# <html><h2>Defines All Language Categories</h2>
# <p><code>$LC_ALL</code> defines the value for all language categories. The value of the LC_ALL environment variable has precedence over any of the other environment variables starting with <code>LC_</code> (<code>LC_COLLATE</code>, <code>LC_CTYPE</code>, <code>LC_MESSAGES</code>, <code>LC_MONETARY</code>, <code>LC_NUMERIC</code>, <code>LC_TIME</code>) and the <code>LANG</code> environment variable.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-LC_005fALL">Bash manual</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_02">POSIX specification</a></li>
# </ul>
# </html>
declare LC_ALL

# <html><h2>LC_COLLATE</h2>
# <p><strong><code>LC_COLLATE</code></strong> defines the collation order for some functions of the shell.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-LC_005fCOLLATE">Bash manual</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_02">POSIX specification</a></li>
# </ul>
# </html>
declare LC_COLLATE

# <html><h2>LC_CTYPE</h2>
# <p><strong><code>LC_CTYPE</code></strong> determines the locale category for character handling functions. <code>LC_ALL</code> is overriding <code>LC_CTYPE</code>. If <code>LC_CTYPE</code> is not set, then the value of <code>LANG</code> is used as a fallback.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-LC_005fCTYPE">Bash manual</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_02">POSIX specification</a></li>
# </ul>
# </html>
declare LC_CTYPE

# <html><h2>LC_MESSAGES</h2>
# <p><strong><code>LC_MESSAGES</code></strong> defines the languages used by the special <code>$&quot;&quot;</code> message handling of your shell. <code>LC_ALL</code> is overriding <code>LC_MESSAGES</code>. If <code>LC_MESSAGES</code> is not set, then the value of <code>LANG</code> is used as a fallback.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-LC_005fMESSAGES-1">Bash manual on LC_MESSAGES</a></li>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Locale-Translation.html#Locale-Translation">Bash manual on locale translation</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_02">POSIX specification</a></li>
# </ul>
# </html>
declare LC_MESSAGES

# <html><h2>LINENO</h2>
# <p><strong>$LINENO</strong> contains the line number, which is currently being executed.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-LINENO">Bash manual</a></li>
# </ul>
# <h3>Examples</h3>
# <pre><code class="language-bash"># prints line 2, this comment is line 1
# echo &quot;line $LINENO&quot;
# </code></pre>
# </html>
declare LINENO

# <html><h2>Locations of message catalogs</h2>
# <p><strong>$NLSPATH</strong> is related to translation lookup in message catalogs. Refer to the specification below for details.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_02">POSIX specification</a></li>
# </ul>
# </html>
declare NLSPATH

# <html><h2>Search path for commands</h2>
# <p><code>$PATH</code> defines where the shell searches for commands.<br />
# Separate entries with colons <code>:</code>. Entries are searched left to right.</p>
# <p>When you invoke a command just by name, e.g. <code>man</code> instead of <code>/usr/bin/man</code>, then the executable file is searched in <code>$PATH</code>.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Variables.html#index-PATH">Bash manual</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_03">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Current Directory</dt>
# <dd>Lookup commands in the current directory first
# <pre><code class="language-bash">export PATH=&quot;.:$PATH&quot;
# </code></pre>
# </dd>
# <dt>Multiple Directories</dt>
# <dd>Lookup commands first in <code>/usr/local/bin</code>, then in the previously declared directories:
# <pre><code class="language-bash">export PATH=&quot;/usr/local/bin:$PATH&quot;
# </code></pre>
# </dd>
# </dl>
# </html>
declare PATH

# <html><h2>Parent Process ID</h2>
# <p>The read–only <strong>$PPID</strong> variable contains the process id of the shell&rsquo;s parent process.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-PPID">Bash manual</a></li>
# </ul>
# </html>
declare -r PPID

# <html><h2>Primary Prompt String</h2>
# <p><strong>$PS1</strong> defines the primary prompt string of your shell. Only shells running in interactive mode use it.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Variables.html#index-PS1">Bash manual</a></li>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html#Controlling-the-Prompt">Bash manual on &quot;Controlling the Prompt</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/xrat/V4_xcu_chap02.html#tag_23_02_05_03">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <pre><code class="language-bash"># Bash: &quot;username@hostname current/dir/path &gt; &quot; as prompt 
# export PS1=&quot;\u@\h \w&gt; &quot;
# </code></pre>
# </html>
declare PS1

# <html><h2>Secondary Prompt String</h2>
# <p><strong>$PS2</strong> defines the secondary prompt string of your shell. It&rsquo;s used for line continuations. Only shells running in interactive mode use it.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Variables.html#index-PS2">Bash manual</a></li>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html#Controlling-the-Prompt">Bash manual on &ldquo;Controlling the Prompt&rdquo;</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/xrat/V4_xcu_chap02.html#tag_23_02_05_03">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <pre><code class="language-bash"># Bash: lines, which continue a previous line, are prefixed with &quot;&gt;&gt; &quot;
# # Enter `echo \` followed by enter in an interactive shell to see it 
# export PS2=&quot;&gt;&gt; &quot;
# </code></pre>
# </html>
declare PS2

# <html><h2>Shell Debugging Prompt String</h2>
# <p><strong>$PS4</strong> defines the prompt string of your shell, which is printed during shell debugging. It&rsquo;s printed when line tracing is enabled, e.g. by calling <code>set -x</code>.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html#index-PS4">Bash manual</a></li>
# <li><a href="https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html#Controlling-the-Prompt">Bash manual on &quot;Controlling the Prompt</a></li>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/xrat/V4_xcu_chap02.html#tag_23_02_05_03">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <pre><code class="language-bash"># Print a command's line number before executing it
# PS4='[${LINENO}]+ '
# set -x
# echo Hello
# </code></pre>
# </html>
declare PS4

# <html><h2>Current Working Directory</h2>
# <p><code>$PWD</code> contains the absolute pathname of the current working directory.</p>
# <p>The <code>pwd</code> command is helpful to work with the working directory.</p>
# <h3>Live Templates</h3>
# <p>The <code>dir_posix</code> and <code>dir_bash</code> live template insert a command to retrieve the full to the directory, where the current script is located:</p>
# <pre><code class="language-bash"># Live template dir_posix inserts this:
# DIR=&quot;$(CDPATH='' cd -- &quot;$(dirname -- &quot;$0&quot;)&quot; &amp;&amp; pwd -P)&quot;
# </code></pre>
# </html>
declare PWD

# <html><h2>Command Name</h2>
# <p><strong><code>$0</code></strong> is the name of the currently executed command. If a function is executed, then <code>$0</code> is the name of the script.</p>
# <p>Bash 5.0 and later allows modifications of <code>$0</code> via <code>BASH_ARGV0</code>. Values assigned to <code>BASH_ARGV0</code> automatically apply to <code>$0</code>.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print command name</dt>
# <dd>
# <pre><code class="language-bash">echo $0
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 0

# <html><h2>1st Positional Parameter</h2>
# <p><strong><code>$1</code></strong> is the value of the first positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 1st parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $1
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${1-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 1

# <html><h2>2nd Positional Parameter</h2>
# <p><strong><code>$2</code></strong> is the value of the second positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 2nd parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $2
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${2-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 2

# <html><h2>3rd Positional Parameter</h2>
# <p><strong><code>$3</code></strong> is the value of the third positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 3rd parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $3
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${3-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 3

# <html><h2>4th Positional Parameter</h2>
# <p><strong><code>$4</code></strong> is the value of the fourth positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 4th parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $4
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${4-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 4

# <html><h2>5th Positional Parameter</h2>
# <p><strong><code>$5</code></strong> is the value of the fifth positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 5th parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $5
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${5-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 5

# <html><h2>6th Positional Parameter</h2>
# <p><strong><code>$6</code></strong> is the value of the sixth positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 6th parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $6
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${6-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 6

# <html><h2>7th Positional Parameter</h2>
# <p><strong><code>$7</code></strong> is the value of the seventh positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9799919799/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 7th parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $7
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${7-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 7

# <html><h2>8th Positional Parameter</h2>
# <p><strong><code>$8</code></strong> is the value of the eighth positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9899919899/utilities/V3_chap02.html#tag_18_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 8th parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $8
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${8-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 8

# <html><h2>9th Positional Parameter</h2>
# <p><strong><code>$9</code></strong> is the value of the ninth positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9999919999/utilities/V3_chap02.html#tag_19_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 9th parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo $9
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${9-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 9

# <html><h2>10th Positional Parameter</h2>
# <p><strong><code>$10</code></strong> is the value of the ninth positional parameter. It has to be referenced as parameter expansion, e.g. <code>${10}</code>.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9999919999/utilities/V3_chap02.html#tag_19_01">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print 10th parameter value</dt>
# <dd>
# <pre><code class="language-bash">echo ${10}
# </code></pre>
# </dd>
# <dt>Print with a fallback value</dt>
# <dd>
# <pre><code class="language-bash">echo ${10-Fallback value}
# </code></pre>
# </dd>
# </dl>
# </html>
declare -r 10

# <html><h2>Positional Parameters</h2>
# <p><strong><code>$@</code></strong> expands to the positional parameters <code>$1</code>, &hellip; producing one field for each parameter.</p>
# <p><code>$*</code> is similar, but only produces a single value, which contains all values at once.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_02">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print all positional parameters</dt>
# <dd>
# <pre><code class="language-bash">set a b
# for p in &quot;$@&quot;; do echo &quot;value: $p&quot;; done
# </code></pre>
# </dd>
# </dl>
# <p>Output: <code>value: a</code> and <code>value: b</code>.</p>
# </html>
declare @

# <html><h2>Positional Parameters</h2>
# <p><strong><code>$*</code></strong> expands to a single word, which contains the values of all positional parameters <code>$1</code>, &hellip; .</p>
# <p><code>$@</code> is similar, but produces multiple values, one for each positional parameter.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_02">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print positional parameters as one value</dt>
# <dd>
# <pre><code class="language-bash">set a b
# for p in &quot;$*&quot;; do echo &quot;value: $p&quot;; done
# </code></pre>
# </dd>
# </dl>
# <p>Output: <code>value: a b</code>.</p>
# </html>
declare *

# <html><h2>Number of Positional Parameters</h2>
# <p><strong><code>$#</code></strong> is the number of available positional parameters <code>$1</code>, <code>$2</code>, etc.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_02">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print number of positional parameters</dt>
# <dd>
# <pre><code class="language-bash">set a b c 
# echo &quot;$#&quot;
# </code></pre>
# </dd>
# </dl>
# <p>Output: <code>3</code>.</p>
# </html>
declare '#'

# <html><h2>Exit Status</h2>
# <p><strong><code>$?</code></strong> is the decimal exit status of the most recent command executed.</p>
# <p>Following the execution of a pipe, <code>$?</code> gives the exit status of the last command executed.</p>
# <p>Following the execution of a function, <code>$?</code> gives the exit status the last command executed in the function. The <code>return</code> builtin command allows to define the exit status of a function.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_02">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Return from function with exit status 2</dt>
# <dd>
# <pre><code class="language-bash">a() { return 2; }
# a
# echo $?
# </code></pre>
# </dd>
# </dl>
# <p>Output: <code>2</code>.</p>
# </html>
declare ?

# <html><h2>Current Option Flags</h2>
# <p><strong><code>$-</code></strong> expands to the current option flags.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_02">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print option flags</dt>
# <dd>
# <pre><code class="language-bash">echo &quot;$-&quot;
# </code></pre>
# </dd>
# </dl>
# <p>Possible output: <code>himBHs</code>.</p>
# </html>
declare '-'

# <html><h2>Shell Process ID</h2>
# <p><strong><code>$$</code></strong> expands to the process ID of the invoked shell. In a subshell it expands to the same ID as that of the parent process.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_02">POSIX specification</a></li>
# </ul>
# <h3>Examples</h3>
# <dl>
# <dt>Print PID of the Shell twice</dt>
# <dd>
# <pre><code class="language-bash"># main
# echo &quot;$$&quot;
# # subshell
# (echo &quot;$$&quot;)
# </code></pre>
# </dd>
# </dl>
# </html>
declare $

# <html><h2>PID of Background Command</h2>
# <p><strong><code>$!</code></strong> expands to the process ID of the most recent background command executed in the current shell.</p>
# <h3>Links</h3>
# <ul>
# <li><a href="https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_05_02">POSIX specification</a></li>
# </ul>
# </html>
declare !