This is BashSupport Pro.
Website: https://www.bashsupport.com/

Licenses of used software components are available in ./licenses.
Sources of used software components are available in ./sources.

Online git repositories of the same sources:
- https://github.com/BashSupport-Pro/shellcheck
- https://github.com/BashSupport-Pro/sh
- https://github.com/BashSupport-Pro/bashdb
- https://github.com/BashSupport-Pro/bats-core
- https://github.com/BashSupport-Pro/pty4j